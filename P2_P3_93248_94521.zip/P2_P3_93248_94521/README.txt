1. Criar um virtual environment com os requirements do client e do server
2. Ativar o mesmo para correr tanto o código do client como do server

Flags server: 
$python3 server.py -e [encriptar os ficheiros - primeiro comando a correr]
$python3 server.py -d [desencriptar os ficheiros, o servidor fecha depois de terminado o processo]
$python3 server.py    [correr o servidor normalmente depois dos ficheiros encriptados]

A ordem natural deve ser: 
$python3 server.py -e
$python3 client.py 

Caso se queira reiniciar o servidor depois dos comandos acima: 
$python3 server.py
$python3 client.py

Caso se queira apenas desencriptar os ficheiros:
$python3 server.py -d


Será necessário ter os seguintes requisitos, também, instalados: 
apt install pcscd
pip3 install pykcs11 (que poderá dar erro devido ao swig: apt install swig)
opcional: apt install opensc-pkcs11
